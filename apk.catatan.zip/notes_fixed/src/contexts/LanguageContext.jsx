import React from 'react';

const LanguageContext = React.createContext();

export const LanguageProvider = ({ children }) => {
  const [locale, setLocale] = React.useState(localStorage.getItem('locale') || 'id');

  const toggleLocale = () => {
    setLocale((prevLocale) => {
      const newLocale = prevLocale === 'id' ? 'en' : 'id';
      localStorage.setItem('locale', newLocale);
      return newLocale;
    });
  };

  const contextValue = React.useMemo(() => {
    return {
      locale,
      toggleLocale
    };
  }, [locale]);

  return (
    <LanguageContext.Provider value={contextValue}>
      {children}
    </LanguageContext.Provider>
  );
};

export default LanguageContext;