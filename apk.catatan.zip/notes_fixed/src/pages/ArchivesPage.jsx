import React from 'react';
import { Link } from 'react-router-dom';
import { getArchivedNotes, deleteNote, unarchiveNote } from '../utils/network-data';
import { showFormattedDate } from '../utils/index';

function ArchivesPage() {
  const [notes, setNotes] = React.useState([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    async function fetchArchivedNotes() {
      const { error, data } = await getArchivedNotes();
      if (!error) {
        setNotes(data);
      }
      setLoading(false);
    }
    fetchArchivedNotes();
  }, []);

  async function onDeleteHandler(id) {
    const { error } = await deleteNote(id);
    if (!error) {
      const { data } = await getArchivedNotes();
      setNotes(data);
    }
  }

  async function onUnarchiveHandler(id) {
    const { error } = await unarchiveNote(id);
    if (!error) {
      const { data } = await getArchivedNotes();
      setNotes(data);
    }
  }

  if (loading) {
    return <p>Memuat arsip...</p>;
  }

  return (
    <section className="archives-page">
      <h2>Catatan Arsip</h2>
      <div className="homepage__action">
        <Link to="/">Kembali ke Catatan Aktif</Link>
      </div>

      {notes.length > 0 ? (
        <div className="notes-list">
          {notes.map((note) => (
            <article key={note.id} className="note-item">
              <h3 className="note-item__title">
                <Link to={`/notes/${note.id}`}>{note.title}</Link>
              </h3>
              <p className="note-item__createdAt">{showFormattedDate(note.createdAt)}</p>
              <p className="note-item__body">{note.body}</p>
              <div className="note-item__action">
                <button className="action-delete" onClick={() => onDeleteHandler(note.id)}>Hapus</button>
                <button className="action-unarchive" onClick={() => onUnarchiveHandler(note.id)}>Pindahkan</button>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <p className="notes-list__empty-message">Arsip kosong</p>
      )}
    </section>
  );
}

export default ArchivesPage;
