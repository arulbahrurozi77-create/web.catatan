import React from 'react';
import LanguageContext from '../contexts/LanguageContext.jsx';
import { Link, useSearchParams } from 'react-router-dom';
import { getActiveNotes, deleteNote, archiveNote } from '../utils/network-data';
import { showFormattedDate } from '../utils/index';

function HomePage() {
  const { locale } = React.useContext(LanguageContext);
  const [notes, setNotes] = React.useState([]);
  const [loading, setLoading] = React.useState(true);

  const [searchParams, setSearchParams] = useSearchParams();
  const keyword = searchParams.get('keyword') || '';

  React.useEffect(() => {
    async function fetchNotes() {
      setLoading(true);
      const { error, data } = await getActiveNotes();
      if (!error) {
        setNotes(data);
      }
      setLoading(false);
    }
    fetchNotes();
  }, []);

  async function onDeleteHandler(id) {
    const { error } = await deleteNote(id);
    if (!error) {
      const { data } = await getActiveNotes();
      setNotes(data);
    }
  }

  async function onArchiveHandler(id) {
    const { error } = await archiveNote(id);
    if (!error) {
      const { data } = await getActiveNotes();
      setNotes(data);
    }
  }

  function onKeywordChangeHandler(event) {
    setSearchParams({ keyword: event.target.value });
  }

  const filteredNotes = notes.filter((note) => {
    return note.title.toLowerCase().includes(keyword.toLowerCase());
  });

  if (loading) {
    return <p>Memuat catatan...</p>;
  }

  return (
    <section>
      <h2>{locale === 'id' ? 'Catatan Aktif' : 'Active Notes'}</h2>

      <section className="search-bar">
        <input
          type="text"
          placeholder={locale === 'id' ? 'Cari berdasarkan judul...' : 'Search by title...'}
          value={keyword}
          onChange={onKeywordChangeHandler}
        />
      </section>

      <div className="homepage__action">
        <Link to="/notes/new" title="Tambah">Tambah Catatan Baru</Link>
      </div>

      {filteredNotes.length > 0 ? (
        <div className="notes-list">
          {filteredNotes.map((note) => (
            <article key={note.id} className="note-item">
              <h3 className="note-item__title">
                <Link to={`/notes/${note.id}`}>{note.title}</Link>
              </h3>
              <p className="note-item__createdAt">{showFormattedDate(note.createdAt)}</p>
              <p className="note-item__body">{note.body}</p>
              <div className="note-item__action">
                <button className="action-delete" onClick={() => onDeleteHandler(note.id)}>Hapus</button>
                <button className="action-archive" onClick={() => onArchiveHandler(note.id)}>Arsipkan</button>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <p className="notes-list__empty-message">
          {locale === 'id' ? 'Tidak ada catatan' : 'No notes found'}
        </p>
      )}
    </section>
  );
}

export default HomePage;
