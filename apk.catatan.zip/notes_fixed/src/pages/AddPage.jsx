import React from 'react';
import { useNavigate } from 'react-router-dom';
import { addNote } from '../utils/network-data';

function AddPage() {
  const [title, setTitle] = React.useState('');
  const [body, setBody] = React.useState('');
  const [loading, setLoading] = React.useState(false);

  const navigate = useNavigate();

  function onTitleChangeEventHandler(event) {
    setTitle(event.target.value);
  }

  function onBodyChangeEventHandler(event) {
    setBody(event.target.value);
  }

  async function onSubmitEventHandler(event) {
    event.preventDefault();
    setLoading(true);
    const { error } = await addNote({ title, body });
    setLoading(false);
    if (!error) {
      navigate('/');
    }
  }

  return (
    <section className="add-new-page">
      <h2>Tambah Catatan Baru</h2>
      <form className="add-new-page__input" onSubmit={onSubmitEventHandler}>
        <input
          className="add-new-page__input__title"
          type="text"
          placeholder="Catatan rahasia"
          value={title}
          onChange={onTitleChangeEventHandler}
          required
        />
        <textarea
          className="add-new-page__input__body"
          placeholder="Isi catatanmu di sini..."
          value={body}
          onChange={onBodyChangeEventHandler}
          required
        />
        <div className="add-new-page__action">
          <button className="action" type="submit" title="Simpan" disabled={loading}>
            {loading ? 'Menyimpan...' : 'Simpan'}
          </button>
        </div>
      </form>
    </section>
  );
}

export default AddPage;
