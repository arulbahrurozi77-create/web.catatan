import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getNote, deleteNote, archiveNote, unarchiveNote } from '../utils/network-data';
import { showFormattedDate } from '../utils/index';

function DetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [note, setNote] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    async function fetchNote() {
      const { error, data } = await getNote(id);
      if (!error) {
        setNote(data);
      }
      setLoading(false);
    }
    fetchNote();
  }, [id]);

  async function onDeleteHandler() {
    const { error } = await deleteNote(id);
    if (!error) {
      navigate('/');
    }
  }

  async function onArchiveHandler() {
    const { error } = await archiveNote(id);
    if (!error) {
      navigate('/archives');
    }
  }

  async function onUnarchiveHandler() {
    const { error } = await unarchiveNote(id);
    if (!error) {
      navigate('/');
    }
  }

  if (loading) {
    return <p>Memuat catatan...</p>;
  }

  if (!note) {
    return <p>Catatan tidak ditemukan!</p>;
  }

  return (
    <section className="detail-page">
      <h3 className="detail-page__title">{note.title}</h3>
      <p className="detail-page__createdAt">{showFormattedDate(note.createdAt)}</p>
      <div className="detail-page__body">{note.body}</div>
      <div className="detail-page__action">
        <button className="action-delete" onClick={onDeleteHandler}>Hapus</button>
        {note.archived ? (
          <button className="action-unarchive" onClick={onUnarchiveHandler}>Pindahkan ke Aktif</button>
        ) : (
          <button className="action-archive" onClick={onArchiveHandler}>Arsipkan</button>
        )}
        <button onClick={() => navigate(-1)}>Kembali</button>
      </div>
    </section>
  );
}

export default DetailPage;
