import React from 'react';
import { register } from '../utils/network-data';
import { Link, useNavigate } from 'react-router-dom';

function useInput(defaultValue = '') {
  const [value, setValue] = React.useState(defaultValue);
  const onValueChangeHandler = (event) => setValue(event.target.value);
  return [value, onValueChangeHandler];
}

function RegisterPage() {
  const [name, onNameChange] = useInput('');
  const [email, onEmailChange] = useInput('');
  const [password, onPasswordChange] = useInput('');
  const [loading, setLoading] = React.useState(false);
  const [errorMsg, setErrorMsg] = React.useState('');
  const navigate = useNavigate();

  async function onSubmitHandler(event) {
    event.preventDefault();
    setLoading(true);
    setErrorMsg('');
    const { error } = await register({ name, email, password });
    setLoading(false);
    if (!error) {
      navigate('/');
    } else {
      setErrorMsg('Pendaftaran gagal. Pastikan semua data sudah benar.');
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-bg-decoration">
        <div className="auth-orb auth-orb--1" />
        <div className="auth-orb auth-orb--2" />
      </div>

      <div className="auth-card">
        <div className="auth-brand">
          <div className="auth-brand__icon">✎</div>
          <span className="auth-brand__name"><span>Aplikasi</span> Catatan</span>
        </div>

        <div className="auth-header">
          <h1 className="auth-title">Buat akun baru</h1>
          <p className="auth-subtitle">Mulai catat ide dan rencanamu hari ini</p>
        </div>

        {errorMsg && (
          <div className="auth-error">
            <span>⚠</span> {errorMsg}
          </div>
        )}

        <form onSubmit={onSubmitHandler} className="auth-form">
          <div className="auth-field">
            <label className="auth-label">Nama Lengkap</label>
            <input
              className="auth-input"
              type="text"
              placeholder="Nama kamu"
              value={name}
              onChange={onNameChange}
              required
            />
          </div>

          <div className="auth-field">
            <label className="auth-label">Email</label>
            <input
              className="auth-input"
              type="email"
              placeholder="nama@email.com"
              value={email}
              onChange={onEmailChange}
              required
            />
          </div>

          <div className="auth-field">
            <label className="auth-label">Password</label>
            <input
              className="auth-input"
              type="password"
              placeholder="Minimal 8 karakter"
              value={password}
              onChange={onPasswordChange}
              required
            />
          </div>

          <button type="submit" className="auth-btn" disabled={loading}>
            {loading ? (
              <span className="auth-btn__loading">
                <span className="auth-spinner" /> Memproses...
              </span>
            ) : 'Daftar Sekarang'}
          </button>
        </form>

        <p className="auth-footer">
          Sudah punya akun?{' '}
          <Link to="/" className="auth-link">Masuk di sini</Link>
        </p>
      </div>
    </div>
  );
}

export default RegisterPage;
