import React from 'react';
import { login, putAccessToken } from '../utils/network-data.js';
import { useNavigate, Link } from 'react-router-dom';

function useInput(defaultValue = '') {
  const [value, setValue] = React.useState(defaultValue);
  const onValueChangeHandler = (event) => setValue(event.target.value);
  return [value, onValueChangeHandler];
}

function LoginPage({ loginSuccess }) {
  const [email, onEmailChange] = useInput('');
  const [password, onPasswordChange] = useInput('');
  const [loading, setLoading] = React.useState(false);
  const [errorMsg, setErrorMsg] = React.useState('');
  const navigate = useNavigate();

  async function onSubmitHandler(event) {
    event.preventDefault();
    setLoading(true);
    setErrorMsg('');
    const { error, data } = await login({ email, password });
    setLoading(false);
    if (!error) {
      putAccessToken(data.accessToken);
      loginSuccess(data);
      navigate('/');
    } else {
      setErrorMsg('Email atau password salah. Silakan coba lagi.');
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-bg-decoration">
        <div className="auth-orb auth-orb--1" />
        <div className="auth-orb auth-orb--2" />
      </div>

      <div className="auth-card">
        <div className="auth-brand">
          <div className="auth-brand__icon">✎</div>
          <span className="auth-brand__name"><span>Aplikasi</span> Catatan</span>
        </div>

        <div className="auth-header">
          <h1 className="auth-title">Selamat datang</h1>
          <p className="auth-subtitle">Masuk untuk melanjutkan ke catatan kamu</p>
        </div>

        {errorMsg && (
          <div className="auth-error">
            <span>⚠</span> {errorMsg}
          </div>
        )}

        <form onSubmit={onSubmitHandler} className="auth-form">
          <div className="auth-field">
            <label className="auth-label">Email</label>
            <input
              className="auth-input"
              type="email"
              placeholder="nama@email.com"
              value={email}
              onChange={onEmailChange}
              required
            />
          </div>

          <div className="auth-field">
            <label className="auth-label">Password</label>
            <input
              className="auth-input"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={onPasswordChange}
              required
            />
          </div>

          <button type="submit" className="auth-btn" disabled={loading}>
            {loading ? (
              <span className="auth-btn__loading">
                <span className="auth-spinner" /> Memproses...
              </span>
            ) : 'Masuk'}
          </button>
        </form>

        <p className="auth-footer">
          Belum punya akun?{' '}
          <Link to="/register" className="auth-link">Daftar sekarang</Link>
        </p>
      </div>
    </div>
  );
}

export default LoginPage;
