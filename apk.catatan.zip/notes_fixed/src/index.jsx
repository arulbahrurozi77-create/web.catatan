import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from "react-router-dom";
import App from './App';
import './styles/style.css';
import { ThemeProvider } from './contexts/ThemeContext';
import LanguageContext, { LanguageProvider } from './contexts/LanguageContext';

const root = createRoot(document.getElementById('root'));
root.render(
 <BrowserRouter>
  <ThemeProvider>
    <LanguageProvider>
      <App />
    </LanguageProvider>
  </ThemeProvider>
 </BrowserRouter>
);
