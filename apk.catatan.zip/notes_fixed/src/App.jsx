import React from 'react';
import ThemeContext from './contexts/ThemeContext.jsx';
import LanguageContext from './contexts/LanguageContext.jsx';
import { Routes, Route, Link, useNavigate } from 'react-router-dom';
import HomePage from './pages/HomePage.jsx';
import LoginPage from './pages/LoginPage.jsx';
import RegisterPage from './pages/RegisterPage.jsx';
import AddPage from './pages/AddPage.jsx';
import DetailPage from './pages/DetailPage.jsx';
import ArchivesPage from './pages/ArchivesPage.jsx';
import { getUserLogged, putAccessToken } from './utils/network-data.js';

function App() {
  const { theme, toggleTheme } = React.useContext(ThemeContext);
  const { locale, toggleLocale } = React.useContext(LanguageContext);
  const [authedUser, setAuthedUser] = React.useState(null);
  const [initializing, setInitializing] = React.useState(true);
  const navigate = useNavigate();

  React.useEffect(() => {
    async function fetchUser() {
      const { data } = await getUserLogged();
      setAuthedUser(data);
      setInitializing(false);
    }
    fetchUser();
  }, []);

  async function onLoginSuccess({ accessToken }) {
    putAccessToken(accessToken);
    const { data } = await getUserLogged();
    setAuthedUser(data);
    navigate('/');
  }

  function onLogout() {
    setAuthedUser(null);
    putAccessToken('');
    navigate('/');
  }

  if (initializing) {
    return (
      <div className="loading-indicator">
        <p>Loading data</p>
      </div>
    );
  }

  if (authedUser === null) {
    return (
      <div className="app-container">
        <header>
          <h1>Aplikasi Catatan</h1>
        </header>
        <main>
          <Routes>
            <Route path="/" element={<LoginPage loginSuccess={onLoginSuccess} />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="*" element={<LoginPage loginSuccess={onLoginSuccess} />} />
          </Routes>
        </main>
      </div>
    );
  }

  return (
    <div className="app-container">
      <header>
        <h1>{locale === 'id' ? <><span>Aplikasi</span> Catatan</> : <><span>Note</span> App</>}</h1>

        {/* Point 2: Tampilkan nama & email user yang sedang login */}
        <div className="user-info">
          <span>👤 {authedUser.name}</span>
          <span className="user-email">({authedUser.email})</span>
        </div>

        <button className="toggle-theme" onClick={toggleTheme}>
          {theme === 'Light' ? 'Dark' : 'Light'}
        </button>
        <button onClick={toggleLocale}>
          {locale === 'id' ? 'English' : 'Indonesian'}
        </button>
        <nav className="navigation">
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/archives">Arsip</Link></li>
          </ul>
        </nav>
        <button className="button-logout" onClick={onLogout}>Logout</button>
      </header>
      <main>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/notes/new" element={<AddPage />} />
          <Route path="/notes/:id" element={<DetailPage />} />
          <Route path="/archives" element={<ArchivesPage />} />
          <Route path="*" element={<h2>Halaman Tidak Ditemukan</h2>} />
        </Routes>
      </main>
    </div>
  );
}

export default App;
